# 🌸 Iris Flower Classifier — Dockerized

A **Random Forest** classifier for the classic Iris dataset, served via a **FastAPI** REST API with a polished web UI. The model is trained at Docker build time and packaged into the image.

---

## Project Structure

```
iris-classifier/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── model/
│   └── train.py          # Trains & saves the model
└── app/
    ├── main.py           # FastAPI app
    └── index.html        # Web UI
```

---

## Quickstart

### Option A — Docker Compose (recommended)

```bash
docker compose up --build
```

### Option B — Plain Docker

```bash
# Build (trains model inside)
docker build -t iris-classifier .

# Run
docker run -p 8000:8000 iris-classifier
```

Open **http://localhost:8000** in your browser.

---

## API

### `POST /predict`

```json
{
  "sepal_length": 5.1,
  "sepal_width":  3.5,
  "petal_length": 1.4,
  "petal_width":  0.2
}
```

**Response:**

```json
{
  "flower": "setosa",
  "confidence": 1.0,
  "probabilities": {
    "setosa": 1.0,
    "versicolor": 0.0,
    "virginica": 0.0
  },
  "model_accuracy": 0.9667
}
```

### `GET /health`

```json
{ "status": "ok", "model_loaded": true }
```

---

## Model Details

| Property       | Value                        |
|----------------|------------------------------|
| Algorithm      | Random Forest (100 trees)    |
| Dataset        | sklearn Iris (150 samples)   |
| Train/Test     | 80% / 20%                    |
| Accuracy       | ~96–100%                     |
| Classes        | setosa, versicolor, virginica |

---

## cURL Example

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"sepal_length":6.3,"sepal_width":3.3,"petal_length":6.0,"petal_width":2.5}'
```
